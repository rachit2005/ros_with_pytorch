import rclpy
from rclpy.node import Node
from text_service.srv import Text


class Client(Node):
    def __init__(self):
        super().__init__("client_input")
        self.client = self.create_client(Text, "sentiment")

        while self.client.wait_for_service(1.0):
            self.get_logger().info(f"waiting for server ....")
    
    def classify(self , text:str)-> str:
        req = Text.Request()
        req.text = text

        self.future = self.client.call_async(req)

def main(args=None):
    rclpy.init(args=args)
    node = Client()

    node.classify(input("enter a financial text to classify: "))
    while rclpy.ok():
        rclpy.spin_once(node)
        if node.future.done():
            try:
                resp = node.future.result()
            except Exception as e:
                node.get_logger().info(f"something happened on client side --> {e}")
            else:
                node.get_logger().info(f"prediction --> {resp.text}")

            break

    rclpy.shutdown()
    node.destroy_node()

if __name__=="__main__":
    main()