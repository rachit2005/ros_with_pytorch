import rclpy
from rclpy.node import Node
from text_service.srv import Text

import pickle , pathlib

import pathlib
from ament_index_python.packages import get_package_share_directory

model_dir = pathlib.Path(get_package_share_directory("ros_with_pytorch_nlp")) / "models"


class Server(Node):
    def __init__(self):
        super().__init__("server_classifier")

        try:
            with open(model_dir / "model.pkl", "rb") as f:  
                self.model = pickle.load(f)

            with open(model_dir / "vectorizer.pkl", "rb") as f:
                self.vectorizer = pickle.load(f)

            with open(model_dir / "encoder.pkl", "rb") as f:
                self.encoder = pickle.load(f)

            self.get_logger().info("✅  Model, vectorizer, encoder loaded.")
        except Exception as e:
            self.get_logger().error(f"❌  Failed to load model files: {e}")
            raise


        self.service = self.create_service(Text , "sentiment" , self.callback)

    def callback(self , req , resp):
        text = req.text

        try:
            X = self.vectorizer.transform([text])
            y = self.model.predict(X)
            predicted_text = self.encoder.inverse_transform(y)[0]

            self.get_logger().info(f"{text} --> predicted as {predicted_text}")
            resp.text = predicted_text
        except Exception as e:
            self.get_logger().info("something happened --> {e}")
            resp.text = "error"

        return resp
    

def main(args=None):
    rclpy.init(args=args)
    node = Server()
    rclpy.spin(node)
    rclpy.shutdown()
    node.destroy_node()


if __name__=="__main__":
    main()

