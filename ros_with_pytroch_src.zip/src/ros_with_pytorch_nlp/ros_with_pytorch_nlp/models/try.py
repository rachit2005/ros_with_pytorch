import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import pandas as pd
import pathlib

# Get the root of the ROS package
root_dir = pathlib.Path(__file__).resolve().parents[1]
# print(root_dir)

# Build the full path to data.csv
data_path = root_dir / "data" / "data.csv"

# print(f"🔍 Loading dataset from: {data_path}")

df = pd.read_csv(data_path, encoding="latin1")

print("✅ Loaded CSV successfully.")
print(df.head())

vectorizer = TfidfVectorizer(max_features=5000)
x = vectorizer.fit_transform(df['Sentence'])

encoder = LabelEncoder()
y = encoder.fit_transform(df['Sentiment'])

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

model = RandomForestClassifier()
model.fit(x_train, y_train)

with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("vectorizer.pkl", "wb") as f:
    pickle.dump(vectorizer, f)

with open("encoder.pkl", "wb") as f:
    pickle.dump(encoder, f)
