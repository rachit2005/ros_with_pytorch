# generated from colcon_powershell/shell/template/hook_prepend_value.ps1.em

colcon_prepend_unique_value PYTHONPATH "$env:COLCON_CURRENT_PREFIX\lib/python3.10/site-packages"
