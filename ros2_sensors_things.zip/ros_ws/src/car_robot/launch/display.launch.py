from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch_ros.actions import Node
import os, json

def generate_launch_description():

    gazebo_pkg = FindPackageShare("gazebo_ros").find("gazebo_ros")
    world = PathJoinSubstitution([gazebo_pkg, "worlds", "empty.world"])

    desc_pkg = FindPackageShare("car_robot").find("car_robot")
    urdf_xacro = PathJoinSubstitution([desc_pkg, "urdf", "robot_2.urdf.xacro"])
    robot_desc = Command(["xacro ", urdf_xacro])

    # --- delete previous entity -------------------------------------------
    delete_cmd = [
        "gz", "service", "-s", "/world/default/delete_entity",
        "--reqtype", "gz.msgs.Entity", "--reptype", "gz.msgs.Boolean",
        "--req", json.dumps({"name": "car_robot"})
    ]

    delete_entity = ExecuteProcess(
        cmd=delete_cmd,
        output="screen"
    )

    # --- spawn entity (2 s after delete) -----------------------------------
    spawn_entity = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        name="spawn_car_robot",
        arguments=[
            "-entity", "car_robot",
            "-topic",  "robot_description",
            "-x", "0", "-y", "0", "-z", "0.4"
        ],
        output="screen",
    )

    return LaunchDescription([
        # 0 Launch Gazebo
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(gazebo_pkg, "launch", "gazebo.launch.py")),
            launch_arguments={"world": world}.items(),
        ),
        # 1 Delete any stale model
        delete_entity,
        # 2 Publish TF tree
        # Publishes TF for every joint (defaults to 0 rad)
        Node(package='joint_state_publisher',
             executable='joint_state_publisher',
             name='joint_state_publisher'),
        # converts the urdf into TF tree
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            name="rsp",
            parameters=[{"robot_description": robot_desc}],
            output="screen",
        ),
        # 3 Spawn (after a pause so /spawn_entity is ready)
        TimerAction(period=2.0, actions=[spawn_entity]),
    ])
